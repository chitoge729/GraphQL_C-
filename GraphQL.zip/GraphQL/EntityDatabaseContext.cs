﻿using Microsoft.EntityFrameworkCore;
using WebApplication3.Data.Models;

namespace WebApplication3
{
    public class EntityDatabaseContext : DbContext
    {
        public EntityDatabaseContext(DbContextOptions<EntityDatabaseContext> options) : base(options) 
        {

        }

        public DbSet<Employee> EmployeeEntity { get; set; }
        public DbSet<Review> ReviewEntity { get; set; }
    }
}
