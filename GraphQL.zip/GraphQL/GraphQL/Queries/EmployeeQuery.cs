﻿using GraphQL;
using GraphQL.Types;
using WebApplication3.Data.Models;
using WebApplication3.GraphQL.Types;
using WebApplication3.Repostories;

namespace WebApplication3.GraphQL.Queries
{
    public class EmployeeQuery : ObjectGraphType
    {
        public EmployeeQuery(EmployeeRepository repository) 
        {
            Field<ListGraphType<EmployeeType>>(
                "employees",
                "Return all the employees",
                resolve: context => repository.GetAllEmployees());

            Field<EmployeeType>(
                "employee",
                "Return employee by id",
                new QueryArguments(new QueryArgument<NonNullGraphType<IntGraphType>> { Name = "id", Description = "Employee Id" }),
                resolve : context => repository.GetEmployeeById(context.GetArgument("id", int.MinValue)));
        }
    }
}
