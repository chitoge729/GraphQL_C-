﻿using GraphQL.Types;
using WebApplication3.Data.Models;
using WebApplication3.GraphQL.Mutations;
using WebApplication3.GraphQL.Queries;

namespace WebApplication3.GraphQL
{
    public class AppSchema : Schema
    {
        public AppSchema(EmployeeQuery query, EmployeeMutation mutation) 
        { 
            this.Query = query;
            this.Mutation = mutation;
        }  


    }
}
