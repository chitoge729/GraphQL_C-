﻿using GraphQL.Types;

namespace WebApplication3.GraphQL.Types
{
    public class ReviewInputType : InputObjectGraphType
    {
        public ReviewInputType()
        {
            Name = "ReviewInputTyoe";
            Field<IntGraphType>("Id");
            Field<IntGraphType>("Rate");
            Field<StringGraphType>("Comment");
            
        }
    }
}
