﻿using GraphQL.Types;

namespace WebApplication3.GraphQL.Types
{
    public class EmployeeInputType : InputObjectGraphType
    {
        public EmployeeInputType()
        {
            Name = "EmployeeInputTyoe";
            Field<IntGraphType>("Id");
            Field<StringGraphType>("FirstName");
            Field<StringGraphType>("LastName");
            Field<StringGraphType>("Email");
            Field<ListGraphType<ReviewInputType>>("Reviews");
        }
    }
}
