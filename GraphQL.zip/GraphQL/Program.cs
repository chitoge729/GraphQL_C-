using GraphiQl;
using GraphQL;
using GraphQL.SystemTextJson;
using Microsoft.EntityFrameworkCore;
using WebApplication3;
using WebApplication3.GraphQL;
using WebApplication3.GraphQL.Mutations;
using WebApplication3.GraphQL.Queries;
using WebApplication3.Repostories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddScoped<EmployeeRepository>();
builder.Services.AddScoped<EmployeeQuery>();
builder.Services.AddScoped<EmployeeMutation>();
builder.Services.AddScoped<AppSchema>();
builder.Services.AddGraphQL(builder => builder
    .AddSystemTextJson());
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<EntityDatabaseContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("SqlDbCon"), sqlServerOptions => sqlServerOptions.CommandTimeout(60)), ServiceLifetime.Transient);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseGraphQL<AppSchema>();

app.UseGraphQLGraphiQL("/ui/graphql");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
