﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Data.Models;
using WebApplication3.Repostories;

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController(EmployeeRepository employeeRepository) : ControllerBase
    {
        private readonly EmployeeRepository _employeeRepository = employeeRepository;
        [HttpGet]
        public IActionResult GetAll()
        {
            var allEMployees = _employeeRepository.GetAllEmployees();
            return Ok(allEMployees);
        }

        [HttpGet("id")]
        public IActionResult Get(int id)
        {
            var employee = _employeeRepository.GetEmployeeById(id);
            return Ok(employee);
        }

        [HttpPost]
        public IActionResult AddEmployee([FromBody]Employee employee)
        {
            _employeeRepository.AddEmployee(employee);
            return Ok();
        }

        [HttpPut("id")]
        public IActionResult UpdateEmployee(int id, [FromBody]Employee employee) 
        {
            var updateEmployee = _employeeRepository.UpdateEmployee(id, employee);
            return Ok(updateEmployee);
        }

        [HttpDelete("id")]
        public IActionResult DeleteEmployee(int id)
        {
            _employeeRepository.DeleteEmployee(id);
            return Ok();
        }
    }
}
